function validateForm(){
    var x = document.forms["accountForm"]["Username"].value;
    if(x==null || x==""){
        alert("Username must be filled out");
        return false;
    }
    var p1=document.forms["accountForm"]["password"].value;
    var p2=document.forms["accountForm"]["password2"].value;
    if(p1!="norielle123" || p2!="norielle123"){
        alert("Passwords do not match")
        return false;
    }
}